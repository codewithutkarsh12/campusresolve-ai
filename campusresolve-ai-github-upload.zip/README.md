# CampusResolve AI

**Campus Incident Intelligence & Prevention** — an original PromptWars prototype.

CampusResolve turns unstructured campus maintenance reports into a structured triage recommendation, surfaces possible duplicate incidents, groups recurring faults, and supports a traceable resolution workflow.

## What is implemented

- Responsive interactive dashboard and incident manager.
- Synthetic example incidents with filtering, search and CSV export.
- Report creation, triage review, status progression and a local audit timeline.
- Recurring-pattern aggregation using category and user-entered location.
- Rules-based triage fallback that is explicitly labelled as demo behavior.
- Optional server-side Gemini triage endpoint at `POST /api/triage`.
- Input bounds, allowlisted category/priority values, schema validation, timeout handling, and a small best-effort in-memory rate limit.
- Unit tests for normalization and model-output validation.

## Transparency and limits

The static UI is a functional prototype; its localStorage records and audit timeline are not production security controls. Without `GEMINI_API_KEY`, triage is a deterministic rules-based demo—not a live AI result. This version does **not** yet implement Firebase Authentication, secure persistent database storage, role enforcement, protected evidence uploads, or a tamper-resistant audit log. Do not use it for real private campus data until those controls are added and verified.

All seeded records are synthetic. No real campus impact, accuracy rate, or time-saving claim is made.

## Run locally

The frontend can be opened as a static page, but the optional `/api/triage` serverless function needs a compatible runtime. With Node.js 20+ and the Vercel CLI available:

```bash
npm test
npx vercel dev
```

Open the local address printed by the CLI. Without a configured Gemini key, the page stays in demo mode. To enable live triage locally, add `GEMINI_API_KEY` to an uncommitted `.env.local` file or the hosting provider's private environment configuration. Never commit real credentials.

## Deploy

This source is compatible with Vercel's static frontend plus `/api/triage.js` function convention. Import the project into a supported deployment provider, configure `GEMINI_API_KEY` privately if live triage is needed, and test the public URL from a fresh session. Cloud Run is not required by the supplied challenge clarification.

For GitHub Pages, the static UI can be published, but the server-side Gemini endpoint will not run there. Use a separate serverless backend or a supported full-stack host for live Gemini integration. Never put the Gemini key in client-side JavaScript to make GitHub Pages call Gemini directly.

## Security notes

- Gemini calls happen server-side only.
- The endpoint validates request size, description length, location length, category, model output and model timeout.
- The in-memory rate limit is best-effort only; it is not a production-grade global rate limiter.
- A shared public backend that calls a paid or quota-limited model should have platform-level abuse protection and cost controls before being opened to public traffic.
- Production work must add authentication, resource authorization, persistent server-enforced state transitions, secure audit storage and access-controlled media storage.

## Tests

```bash
npm test
```

The tests validate the small reusable triage-normalization layer. They do not prove the live Gemini API, production authorization, or deployed end-to-end workflow works.

## Technology disclosure

- HTML, CSS and browser JavaScript for the interactive prototype.
- Node.js serverless function convention for the optional triage API.
- Google Gemini API through its documented HTTP interface when configured.
- No copied end-to-end product or third-party UI component bundle is included.

## PromptWars release checklist

- [ ] Public GitHub repository.
- [ ] Repository size strictly below 10 MB.
- [ ] Exactly one branch.
- [ ] No secrets or private user data committed.
- [ ] Live deployment tested from a clean browser session.
- [ ] Live Gemini integration verified if represented as enabled.
- [ ] Authentication and database authorization implemented before real private records are used.
- [ ] Accessibility and negative security tests completed.
- [ ] Additional event-specific tool requirements checked in the official participant dashboard.
