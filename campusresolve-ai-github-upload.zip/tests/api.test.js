const test = require('node:test');
const assert = require('node:assert/strict');
const handler = require('../api/triage');

function fakeResponse() {
  return {
    headers: {}, statusCode: 200, body: '',
    setHeader(name, value) { this.headers[name.toLowerCase()] = value; },
    end(value) { this.body = value || ''; },
    json() { return JSON.parse(this.body || '{}'); }
  };
}

test('triage API rejects non-POST requests', async () => {
  const req = { method: 'GET', headers: {} };
  const res = fakeResponse();
  await handler(req, res);
  assert.equal(res.statusCode, 405);
  assert.equal(res.headers.allow, 'POST');
  assert.equal(res.json().error, 'METHOD_NOT_ALLOWED');
});

test('triage API safely reports missing Gemini configuration', async () => {
  const previous = process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_API_KEY;
  try {
    const req = { method: 'POST', headers: {}, body: { description: 'Water leak', location: 'B204' } };
    const res = fakeResponse();
    await handler(req, res);
    assert.equal(res.statusCode, 503);
    assert.equal(res.json().error, 'AI_NOT_CONFIGURED');
    assert.doesNotMatch(res.body, /AIza/);
  } finally {
    if (previous !== undefined) process.env.GEMINI_API_KEY = previous;
  }
});
