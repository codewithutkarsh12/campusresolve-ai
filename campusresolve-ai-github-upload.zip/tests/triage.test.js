const test = require('node:test');
const assert = require('node:assert/strict');
const { CATEGORIES, PRIORITIES, normalizeCategory, normalizePriority, validateTriage } = require('../lib/triage');

test('only approved categories survive normalization', () => {
  assert.deepEqual(CATEGORIES, ['plumbing', 'electrical', 'sanitation', 'connectivity', 'equipment', 'other']);
  assert.equal(normalizeCategory('plumbing'), 'plumbing');
  assert.equal(normalizeCategory('shell'), 'other');
  assert.equal(normalizeCategory(null), 'other');
});

test('only approved priority values survive normalization', () => {
  assert.equal(normalizePriority('critical'), 'critical');
  assert.equal(normalizePriority('urgent-now'), 'medium');
  assert.ok(PRIORITIES.includes(normalizePriority(undefined)));
});

test('triage output is bounded, typed and defaults to human review', () => {
  const result = validateTriage({
    title: '  Leak  ', category: 'plumbing', urgency: 'high', summary: 'Water near the entrance',
    evidence: ['The report mentions water'], missingFields: ['Exact room'], confidence: 1.4
  });
  assert.equal(result.title, 'Leak');
  assert.equal(result.category, 'plumbing');
  assert.equal(result.urgency, 'high');
  assert.equal(result.confidence, 1);
  assert.equal(result.requiresReview, true);
  assert.deepEqual(result.missingFields, ['Exact room']);
});

test('invalid object shapes are rejected', () => {
  assert.throws(() => validateTriage(null), TypeError);
  assert.throws(() => validateTriage([]), TypeError);
});
